<ul class="menu">
    <li><a href="horario.php">Horario</a></li>
    <li><a href="perfil.php">Perfil</a></li>
    <li><a href="tipos.php">Tipos</a></li>
    <li><a href="lugar.php">Lugar</a></li>
</ul>
